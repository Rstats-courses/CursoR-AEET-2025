# Load data
data_raw <- read_csv(here("data/individual_seed_production.csv"))

# Select sites for which we want the reports
# sites <- unique(data_raw$site_name)
sites <- c("AEC", "CWT", "SEV")

### Render with a loop

for (i in sites) {
  rmarkdown::render(
    "Rmd_example/Nigro_et_al_report.Rmd",
    params = list(
      site_name = i
    ),
    output_file = paste0("Nigro_report_", i, ".pdf")
  )
}

### Render with a function

render_reports <-
  function(site_name){
    rmarkdown::render(
      "Rmd_example/Nigro_et_al_report.Rmd",
      params = list(
        site_name = site_name
      ),
      output_file = paste0("Nigro_report_", site_name, ".pdf")
    )
  }

lapply(sites, render_reports)
